@extends('layouts.app')

@section('title')
    Tentang Kopi
@endsection

@section('content')

<!-- Home Hero -->
<div class="home-hero">
    <div class="hero-image">
        <img src="{{ asset('assets/home1.jpg') }}" alt="Home 1">
        <div class="overlay-text">Brewed with Purpose</div>
    </div>
    <div class="hero-image">
        <img src="{{ asset('assets/home2.jpg') }}" alt="Home 2">
        <div class="overlay-text">Grounded in Passion</div>
    </div>
</div>

<!-- Home Card Section -->
<div class="home-card-container">
    <div class="home-card">
        <img src="{{ asset('assets/home3.jpg') }}" alt="Home 3">
        <h2>Coffee</h2>
        <a href="{{ route('menu.index', ['subcategory' => 1]) }}">Make Purchase</a>
    </div>
    <div class="home-card">
        <img src="{{ asset('assets/home4.jpg') }}" alt="Home 4">
        <h2>Tentang-Toast</h2>
        <a href="{{ route('menu.index', ['subcategory' => 4]) }}">Make Purchase</a>
    </div>
    <div class="home-card">
        <img src="{{ asset('assets/home5.jpg') }}" alt="Home 5">
        <h2>Non-Coffee</h2>
        <a href="{{ route('menu.index', ['subcategory' => 2]) }}">Make Purchase</a>
    </div>
</div>

<!-- Home Feature Section (Home 6) -->
<div class="home-feature">
    <img src="{{ asset('assets/home6.jpg') }}" alt="Home 6">
    <h2>Browse Cafe Menu</h2>
    <a href="{{ route('menu.index') }}">View Full Menu</a>
</div>


@endsection