@csrf
@php $editing = isset($menu) && $menu @endphp

<div class="mb-4">
    <label>Name</label>
    <input type="text" name="name" value="{{ old('name', $editing ? $menu->name : '') }}">
</div>

<div class="mb-4">
    <label>Price</label>
    <input type="number" name="price" step="0.01" value="{{ old('price', $editing ? $menu->price : '') }}">
</div>

<div class="mb-4">
    <label>Category & Subcategory</label>
    <select name="subcategory_id">
        <option value="">-- Select Subcategory --</option>
        @foreach($categories as $category)
            <optgroup label="{{ $category->name }}">
                @foreach($category->subcategories as $sub)
                    <option value="{{ $sub->id }}" {{ old('subcategory_id', $editing ? $menu->subcategory_id : '') == $sub->id ? 'selected' : '' }}>
                        {{ $sub->name }}
                    </option>
                @endforeach
            </optgroup>
        @endforeach
    </select>
</div>

<div class="mb-4">
    <label>Image</label>
    <input type="file" name="image">
    @if($editing && $menu->image)
        <img src="{{ asset('storage/' . $menu->image) }}" width="100" class="mt-2">
    @endif
</div>

<button type="submit">
    Save
</button>
