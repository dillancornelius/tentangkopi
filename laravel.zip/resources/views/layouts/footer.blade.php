<footer>
    <div class="footer-left">
        <img src="{{ asset('assets/logo.jpg') }}" alt="Logo" style="height: 40px;">
        <div>Jl. Jemb. Gambang Raya No.2, Rt.19/RW.1, Pejagalan, Kec. Penjaringan, Jkt Utara, Daerah Khusus Ibukota Jakarta 14450</div>
        <div>Phone: +62 896 7111 0711</div>
    </div>
    <div class="footer-right">
        <a href="{{ route('about.us') }}">
            <div>About Us</div>
        </a>
        <div>Visit Our Social Media</div>
        <div class="social-icons">
            <a href="https://www.facebook.com/share/1EL8rFzgH6/" target="_blank" aria-label="Facebook">
                <i class="fab fa-facebook"></i>
            </a>
            <a href="https://www.instagram.com/tentangkopi.official" target="_blank" aria-label="Instagram">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="https://youtube.com/@sjibrandgroup8505" target="_blank" aria-label="Youtube">
                <i class="fab fa-youtube"></i>
            </a>
            <a href="https://www.tiktok.com/@tentangkopispace" target="_blank" aria-label="TikTok">
                <i class="fab fa-tiktok"></i>
            </a>
        </div>
    </div>
</footer>
