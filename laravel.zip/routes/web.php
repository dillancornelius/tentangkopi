<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\Admin\OrderStatusController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\MenuManagementController;

Route::get('login', [AuthController::class, 'showLogin'])->middleware('guest')->name('login');
Route::post('login', [AuthController::class, 'login'])->middleware('guest');
Route::post('logout', [AuthController::class, 'logout'])->middleware('auth')->name('logout');
Route::get('register', [AuthController::class, 'showRegister'])->middleware('guest')->name('register');
Route::post('register', [AuthController::class, 'register'])->middleware('guest');

Route::middleware('user')->group(function(){
    Route::get('/', [HomeController::class, 'index'])->name('home');
    Route::get('/menu', [MenuController::class, 'index'])->name('menu.index');
    Route::view('/about-us', 'about-us')->name('about.us');
    Route::get('/checkout', [CartController::class, 'checkout'])->name('checkout');
    Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
    Route::post('/checkout', [CartController::class, 'processCheckout'])->name('checkout.process');
    Route::get('/cart/status', [CartController::class, 'status']);
    Route::get('/checkout/success', fn() => view('checkout.success'))->name('checkout.success');
    Route::post('/cart/update-quantity', [CartController::class, 'updateQuantity'])->name('cart.updateQuantity');
    Route::post('/cart/clear', [CartController::class, 'clearCart'])->name('cart.clear');
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/reviews', [ReviewController::class, 'index'])->name('reviews.index');
});

Route::middleware(['auth', 'user'])->group(function(){
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile.index');
    Route::post('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::post('/orders/reorder/{order}', [OrderController::class, 'reorder'])->name('orders.reorder');
    Route::post('/reviews', [ReviewController::class, 'store'])->name('reviews.store');
    Route::get('/reviews/{review}/edit', [ReviewController::class, 'edit'])->name('reviews.edit');
    Route::put('/reviews/{review}', [ReviewController::class, 'update'])->name('reviews.update');
    Route::delete('/reviews/{review}', [ReviewController::class, 'destroy'])->name('reviews.destroy');
});

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function(){
    Route::view('dashboard', 'admin.dashboard')->name('dashboard');
    Route::get('/status', [OrderStatusController::class, 'index'])->name('status.index');
    Route::patch('/status/{order}', [OrderStatusController::class, 'update'])->name('status.update');
    Route::resource('users', UserController::class)->except(['show']);
    Route::resource('menus', MenuManagementController::class);
});