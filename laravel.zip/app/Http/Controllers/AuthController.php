<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    //Menampilkan laman login
    public function showLogin(){
        return view('auth.login');
    }

    //Logika login atau autentikasi
    public function login(Request $request){
        $credentials = $request->only('email', 'password');

        if(Auth::attempt($credentials)){
            return redirect()->route('home');
        }

        return back()->withErrors(['email' => 'Invalid credentials.']);

    }

    //Logika logout 
    public function logout(){
        Auth::logout();
        return redirect()->route('home');
    }

    //Menampilkan laman register
    public function showRegister(){
        return view('auth.register');
    }

    //Logika register atau pembuatan akun
    public function register(Request $request){
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8'
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password)
        ]);

        Auth::login($user);

        return redirect()->route('home');
    }
}
