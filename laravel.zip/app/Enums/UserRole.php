<?php

namespace App\Enums;

enum UserRole: String
{
    //
    case User = 'user';
    case Admin = 'admin';
}
