@extends('layouts.app')

@section('title')
    Riwayat Pesanan
@endsection

@section('content')
<div class="container">
    <h2 style="text-align:center">Riwayat Pesanan</h2>
    <p style="text-align:center"><small>Silakan refresh halaman untuk update terbaru.</small></p>

@php
    $totalOrders = $orders->count();
@endphp

@forelse($orders as $index => $order)
    <div class="order-history">
        <h4>Pesanan #{{ $totalOrders - $index }} - {{ ucfirst($order->status) }}</h4>
        <p>Total: Rp {{ number_format($order->total, 0, ',', '.') }}</p>
        <p>Alamat: {{ $order->address }}</p>

        <ul>
            @foreach(json_decode($order->items, true) as $item)
                <li>{{ $item['name'] }} x{{ $item['quantity'] }} - Rp {{ number_format($item['price'], 0, ',', '.') }}</li>
            @endforeach
        </ul>

        @auth
            <form method="POST" action="{{ route('orders.reorder', $order->id) }}">
                @csrf
                <button type="submit">Reorder</button>
            </form>
        @endauth

        @guest
            <p class="text-muted">Login untuk melakukan reorder.</p>
        @endguest
    </div>
@empty
    <p style="text-align:center">Belum ada pesanan.</p>
@endforelse
</div>
@endsection
