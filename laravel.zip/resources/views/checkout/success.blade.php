@extends('layouts.app')

@section('title')
    Berhasil
@endsection

@section('content')
    <div class="order-history">
        <h4>✅ Terima kasih!</h1>
        <p>Pesanan Anda telah diterima dan sedang diproses.</p>
        <a href="{{ route('menu.index') }}"><button type="button">Kembali ke Menu</button></a><br>
        <a href="{{ route('orders.index') }}"><button type="button" style="margin-top: 0.5rem;">Tinjau orderan anda</button></a>
    </div>
@endsection
