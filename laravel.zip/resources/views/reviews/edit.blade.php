@extends('layouts.app')

@section('content')
    <h2 style="text-align: center">Edit Ulasan</h2>

    <form action="{{ route('reviews.update', $review) }}" method="POST" class="order-history">
        @csrf
        @method('PUT')
        <textarea name="comment" rows="3" required>{{ $review->comment }}</textarea>
        <br>
        <button type="submit">Update</button>
    </form>
@endsection
