<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Menu;
use App\Models\Order;
use App\Models\OrderItem;

class CartController extends Controller
{
    //Mengambil data keranjang dibedakan sesuai role yang ada
    protected function getCartKey(){
        if(auth()->check()){
            return 'cart_user_' . auth()->id();
        }
        return 'cart_guest_' . session()->getId();
    }

    //Memunculkan keranjang
    public function add(Request $request){
        $menu = Menu::findOrFail($request->menu_id);
        $cartKey = $this->getCartKey();
        $cart = session()->get($cartKey, []);

        if (isset($cart[$menu->id])) {
            $cart[$menu->id]['quantity'] += 1;
        } else {
            $cart[$menu->id] = [
                'name' => $menu->name,
                'price' => $menu->price,
                'quantity' => 1,
            ];
        }

        session()->put($cartKey, $cart);

        return response()->json([
            'cart_count' => array_sum(array_column($cart, 'quantity')),
            'total' => array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart)),
        ]);
    }

    //Update statis terkait keranjang
    public function updateQuantity(Request $request){
        $request->validate([
        'menu_id' => 'required|integer',
        'type' => 'required|in:increase,decrease',
        ]);

        $cartKey = $this->getCartKey();
        $cart = session()->get($cartKey, []);

        if (isset($cart[$request->menu_id])) {
            if ($request->type === 'increase') {
                $cart[$request->menu_id]['quantity'] += 1;
            } elseif ($request->type === 'decrease') {
                $cart[$request->menu_id]['quantity'] -= 1;
                if ($cart[$request->menu_id]['quantity'] < 1) {
                    unset($cart[$request->menu_id]); // Hapus jika quantity < 1
                }
            }

            session()->put($cartKey, $cart);
        }

        return response()->json([
            'success' => true,
            'cart_count' => array_sum(array_column($cart, 'quantity')),
            'total' => array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart)),
        ]);
    }

    //Menghilangkan data keranjang
    public function clearCart(){
        $cartKey = $this->getCartKey();
        session()->forget($cartKey);

        return response()->json(['success' => true]);
    }

    //Mengembalikan jumlah item dan total harga dalam format JSON
    public function status(){
        $cartKey = $this->getCartKey();
        $cart = session()->get($cartKey, []);

        $cartCount = array_sum(array_column($cart, 'quantity'));
        $total = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart));

        return response()->json([
            'cart_count' => $cartCount,
            'total' => $total,
        ]);
    }

    //Menampilkan laman checkout
    public function checkout(){
        $cartKey = $this->getCartKey();
        $cart = session()->get($cartKey, []);

        $deliveryFee = 20000;
        $tax = 0.1; // 10%
        $subtotal = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart));
        $taxAmount = $subtotal * $tax;
        $total = $subtotal + $deliveryFee + $taxAmount;

        return view('checkout.index', compact('cart', 'subtotal', 'deliveryFee', 'taxAmount', 'total'));
    }
    
    //Logika dibalik checkout 
    public function processCheckout(Request $request){
        $cartKey = $this->getCartKey();
        $cart = session()->get($cartKey, []);
        
        if (empty($cart)) {
        return redirect()->route('menu.index')->with('error', 'Keranjang kosong.');
        }

        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'phone' => 'required|string|max:20',
            'address' => 'required|string|max:255',
            'note' => 'nullable|string|max:500',
        ]);

        $deliveryFee = 20000;
        $taxRate = 0.1;

        $subtotal = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart));
        $taxAmount = $subtotal * $taxRate;
        $total = $subtotal + $deliveryFee + $taxAmount;

        // Simpan order
        $order = Order::create([
            'user_id' => auth()->id(),
            'name' => $validated['name'],
            'phone' => $validated['phone'],
            'address' => $validated['address'],
            'note' => $validated['note'] ?? null,
            'items' => json_encode($cart),
            'delivery_fee' => $deliveryFee,
            'tax' => $taxAmount,
            'total' => $total,
            'status' => 'pending',
        ]);

        // Simpan setiap item dari cart ke `order_items`
        foreach ($cart as $menuId => $item) {
            OrderItem::create([
                'order_id' => $order->id,
                'menu_id' => $menuId,
                'name' => $item['name'],
                'price' => $item['price'],
                'quantity' => $item['quantity'],
            ]);
        }

        // Kosongkan cart
        session()->forget($this->getCartKey());

        return redirect()->route('checkout.success')->with('success', 'Pesanan berhasil dibuat!');
            return redirect()->route('checkout.success');
        }
}
