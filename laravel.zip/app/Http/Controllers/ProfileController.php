<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class ProfileController extends Controller
{
    //Menampilkan laman profile
    public function index(){
        return view('profile.index',['user' => Auth::user()]);
    }

    //Update nama,email,dan password
    public function update(Request $request){
        $user = Auth::user();

        //Validasi
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255|unique:users,name' . $user->id,
            'email' => 'required|string|email|max:255|unique:users,email' . $user->id,
            'password' => 'nullable|string|min:8|confirmed',
        ]);

        if($validator->fails()){
            return redirect()->route('profile.index')->withErrors($validator)->withInput(); 
        }

        $user->name = $request->input('name');
        $user->email = $request->input('email');

        if($request->filled('password')){
            $user->password = Hash::make($request->input('password'));
        }

        $user->save();

        return redirect()->route('profile.index')->with('success', 'Profile updated successfully');
    }

    //Menghapus akun
    public function destroy(){
        $user = Auth::user();
        $user->delete();

        return redirect()->route('home')->with('success', 'Account deleted successfully');
    }

}
