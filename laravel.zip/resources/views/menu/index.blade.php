@extends('layouts.app')

@section('title')
    Menu
@endsection

@section('content')
<div class="menu-page">
    <aside class="menu-sidebar">
        <h2><a href="{{ route('menu.index') }}">Kategori</a></h2>
        <ul class="category-list">
            @foreach($categories as $category)
                <li class="category">
                    <strong>{{ $category->name }}</strong>
                    <ul class="subcategory-list">
                        @foreach($category->subcategories as $subcategory)
                            <li>
                                <a href="{{ route('menu.index', ['subcategory' => $subcategory->id]) }}"
                                   class="{{ request('subcategory') == $subcategory->id ? 'active' : '' }}">
                                    {{ $subcategory->name }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </li>
            @endforeach
        </ul>

        <form method="GET" action="{{ route('menu.index') }}" class="menu-filter-form">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari menu" class="filter-input">

            <select name="sort" class="filter-select">
                <option value="">Urutkan</option>
                <option value="price_asc" {{ request('sort') == 'price_asc' ? 'selected' : '' }}>Harga Terendah</option>
                <option value="price_desc" {{ request('sort') == 'price_desc' ? 'selected' : '' }}>Harga Tertinggi</option>
                <option value="name_asc" {{ request('sort') == 'name_asc' ? 'selected' : '' }}>Nama (A-Z)</option>
            </select>

            @if(request('subcategory'))
                <input type="hidden" name="subcategory" value="{{ request('subcategory') }}">
            @endif

            <button type="submit" class="filter-button">Terapkan</button>
        </form>
    </aside>

    <main class="menu-content">
        @forelse($menus as $menu)
            <div class="menu-card">
                <div class="image-box">
                <img src="{{ $menu->image ? asset('storage/' . $menu->image) : asset('assets/menu/' . $menu->name . '.png') }}" alt="{{ $menu->name }}" alt="{{ $menu->name }}">
                </div>
            <div class="menu-info">
                    <h4>{{ $menu->name }}</h4>
                    <p class="price">Rp {{ number_format($menu->price, 0, ',', '.') }}</p>
                    <button class="add-to-cart-btn" data-menu-id="{{ $menu->id }}" data-name="{{ $menu->name }}" data-price="{{ $menu->price }}">
                        Tambah ke Keranjang
                    </button>
                </div>
            </div>
        @empty
            <p class="no-menu">Tidak ada menu tersedia.</p>
        @endforelse

        <div id="mini-cart" class="mini-cart hidden" data-checkout-url="{{ route('checkout') }}">
            <i class="fas fa-shopping-cart cart-icon" aria-hidden="true"></i>    
            <span id="cart-count">0 item</span>
            <span id="cart-total">Rp 0</span>
        </div>
    </main>
</div>
@endsection
