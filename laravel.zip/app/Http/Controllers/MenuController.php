<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Menu;

class MenuController extends Controller
{
    //Menampilkan laman menu dan mengambil data menu
    public function index(Request $request){
        $subcategoryId = $request->input('subcategory');
        $search = trim($request->input('search'));
        $sort = $request->input('sort');

        $categories = Category::with('subcategories')->get();

        $menus = Menu::with('subcategory')
            ->when($subcategoryId, fn($q) => $q->where('subcategory_id', $subcategoryId))
            ->when($search, fn($q) => $q->whereRaw("name ~* ?", ['\\m' . preg_quote($search)]))
            ->when($sort, function($q) use ($sort){
                if($sort === 'price_asc') $q->orderBy('price');
                elseif($sort === 'price_desc') $q->orderByDesc('price');
                elseif($sort === 'name_asc') $q->orderBy('name');
            })->get();
        
        return view('menu.index', compact('categories', 'menus', 'search', 'sort'));
    }
}
