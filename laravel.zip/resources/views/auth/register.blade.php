@extends('layouts.app')

@section('title')
    Register - Tentang Kopi
@endsection

@section('content')
<form action="{{ route('register') }}" method="POST" class="auth-form">
    @csrf

    <div class="form-group">
        <label for="name">Name</label>
        <input
            type="name"
            id="name"
            name="name"
            value="{{ old('name') }}"
            placeholder="Enter your name"
            required
        >
        @error('name')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group">
        <label for="email">Email</label>
        <input
            type="email"
            id="email"
            name="email"
            value="{{ old('email') }}"
            placeholder="Enter your email"
            required
        >
        @error('email')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group">
        <label for="password">Password</label>
        <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            required
        >
        <div class="checkbox-wrapper">
            <input type="checkbox" id="show-password" onclick="togglePassword()"> 
            <label for="show-password">Show Password</label>
        </div>
        @error('password')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit">Register</button>
</form>
@endsection
