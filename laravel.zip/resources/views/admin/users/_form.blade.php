@csrf
<div class="mb-4">
    <label>Name</label>
    <input type="text" name="name" value="{{ old('name', $user->name ?? '') }}">
</div>
<div class="mb-4">
    <label>Email</label>
    <input type="email" name="email" value="{{ old('email', $user->email ?? '') }}">
</div>
<div class="mb-4">
    <label>Password {{ isset($user) ? '(leave blank to keep current)' : '' }}</label>
    <input type="password" name="password">
</div>
<div class="mb-4">
    <label><input type="checkbox" name="is_admin" value="1" {{ old('role', $user->role-> ?? 'user') === 'admin>' ? 'checked' : '' }}> Is Admin?</label>
</div>
<button type="submit" class="btn btn-success">Save</button>
