<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Review;
use Illuminate\Support\Facades\Auth;

class ReviewController extends Controller
{
    //Menampilkan laman ulasan beserta data ulasan
    public function index(){
        $reviews = Review::with('user')->latest()->get();
        return view('reviews.index', compact('reviews'));
    }

    //Menyimpan data ulasan dari user
    public function store(Request $request){
        if (!Auth::check()) {
            return redirect()->route('reviews.index')->with('error', 'Login untuk menambahkan ulasan.');
        }

        $request->validate([
            'comment' => 'required|string|max:1000',
        ]);

        Review::create([
            'user_id' => Auth::id(),
            'comment' => $request->comment,
        ]);

        return redirect()->route('reviews.index')->with('success', 'Ulasan ditambahkan.');
    }

    //Menampilkan laman edit
    public function edit(Review $review){
        if (Auth::id() !== $review->user_id) {
            abort(403);
        }

        return view('reviews.edit', compact('review'));
    }

    //Logika untuk update ulasan
    public function update(Request $request, Review $review){
        if (Auth::id() !== $review->user_id) {
            abort(403);
        }

        $request->validate([
            'comment' => 'required|string|max:1000',
        ]);

        $review->update(['comment' => $request->comment]);

        return redirect()->route('reviews.index')->with('success', 'Ulasan diperbarui.');
    }

    //Menghapus ulasan
    public function destroy(Review $review){
        if (Auth::id() !== $review->user_id) {
            abort(403);
        }

        $review->delete();

        return redirect()->route('reviews.index')->with('success', 'Ulasan dihapus.');
    }
}
