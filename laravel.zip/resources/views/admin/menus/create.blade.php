@extends('layouts.admin')

@section('content')
<h1>Create Menu</h1>

<form method="POST" action="{{ route('admin.menus.store') }}" enctype="multipart/form-data">
    @include('admin.menus._form', ['menu' => null])
</form>
@endsection
