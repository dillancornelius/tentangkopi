@extends('layouts.app')

@section('title')
    Login - Tentang Kopi
@endsection

@section('content')
<form action="{{ route('login') }}" method="POST" class="auth-form">
    @csrf

    <div class="form-group">
        <label for="email">Email</label>
        <input
            type="email"
            id="email"
            name="email"
            value="{{ old('email') }}"
            placeholder="Enter your email"
            required
        >
        @error('email')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group">
        <label for="password">Password</label>
        <input
            type="password"
            id="password"
            name="password"
            placeholder="Enter your password"
            required
        >
        @error('password')
            <div class="error">{{ $message }}</div>
        @enderror
    </div>

    <button type="submit">Login</button>

    <p>
        Don't have an account?
        <a href="{{ route('register') }}">Register here</a>
    </p>
</form>

@endsection

