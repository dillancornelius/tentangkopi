<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class OrderController extends Controller
{
    //Menampilkan laman order history
    public function index(){
        $orders = Order::where('user_id', auth()->id())->orderBy('created_at', 'desc')->get();
        return view('orders.index', compact('orders'));
    }

    //Logika untuk pemesanan ulang
    public function reorder(Order $order){
        if ($order->user_id !== auth()->id()) {
            abort(403);
        }

        $cartKey = auth()->check() ? 'cart_user_' . auth()->id() : 'cart';
        session()->put($cartKey, json_decode($order->items, true));

        return redirect()->route('checkout')->with('success', 'Item berhasil dimasukkan kembali ke keranjang.');
    }
}
