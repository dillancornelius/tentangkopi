@extends('layouts.admin')

@section('content')
<h1>Edit Menu</h1>

<form method="POST" action="{{ route('admin.menus.update', $menu) }}" enctype="multipart/form-data">
    @method('PUT')
    @include('admin.menus._form', ['menu' => $menu])
</form>
@endsection
