@extends('layouts.admin')

@section('content')
<h1>Menus</h1>

<a href="{{ route('admin.menus.create') }}" class="btn">+ Add Menu</a>

<table>
    <thead>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Subcategory</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($menus as $menu)
        <tr>
            <td>
                @if($menu->image)
                    <img src="{{ asset('storage/'.$menu->image) }}" width="50">
                @else
                    N/A
                @endif
            </td>
            <td>{{ $menu->name }}</td>
            <td>Rp {{ number_format($menu->price, 0, ',', '.') }}</td>
            <td>{{ $menu->subcategory->category->name ?? '-' }}</td>
            <td>{{ $menu->subcategory->name }}</td>
            <td>
                <a href="{{ route('admin.menus.edit', $menu) }}" class="btn btn-success">Edit</a>
                <form action="{{ route('admin.menus.destroy', $menu) }}" method="POST" class="inline" onsubmit="return confirm('Delete this menu?')">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@if ($menus->hasPages())
    <ul class="pagination">
        {{-- Previous Page Link --}}
        @if ($menus->onFirstPage())
            <li class="disabled"><span>&laquo;</span></li>
        @else
            <li><a href="{{ $menus->previousPageUrl() }}" rel="prev">&laquo;</a></li>
        @endif

        {{-- Pagination Elements --}}
        @foreach ($menus->links()->elements[0] as $page => $url)
            @if ($page == $menus->currentPage())
                <li class="active"><span>{{ $page }}</span></li>
            @else
                <li><a href="{{ $url }}">{{ $page }}</a></li>
            @endif
        @endforeach

        {{-- Next Page Link --}}
        @if ($menus->hasMorePages())
            <li><a href="{{ $menus->nextPageUrl() }}" rel="next">&raquo;</a></li>
        @else
            <li class="disabled"><span>&raquo;</span></li>
        @endif
    </ul>
@endif
@endsection
