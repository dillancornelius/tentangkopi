@extends('layouts.admin')

@section('content')
<h1>Admin Dashboard</h1>
<p>Only visible to admins.</p>


@endsection