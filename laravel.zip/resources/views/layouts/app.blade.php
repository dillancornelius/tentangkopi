<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>@yield('title')</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('css/menu.css') }}">
    <link rel="stylesheet" href="{{ asset('css/auth.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="icon" type="image/jpg" href="{{ asset('assets/logo.jpg') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
<body>

    @include('layouts.header')

    <main style="padding: 2rem;">
        @yield('content')
    </main>

    @include('layouts.footer')


<script src="js/script.js"></script>
</body>
</html>
