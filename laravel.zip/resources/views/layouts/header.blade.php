<header>
    <nav>
        <div class="nav-left">
            <a href="{{ url('/') }}">
                <img src="{{ asset('assets/logo.jpg') }}" alt="CoffeeShop Logo">
            </a>
        </div>
        <div class="nav-right">
            <a href="{{ url('/') }}">Home</a>
            <a href="{{ route('menu.index') }}">Menu</a>
            <a href="{{ route('about.us') }}">About Us</a>
            <a href="{{ route('orders.index') }}">Order History</a>
            <a href="{{ route('reviews.index') }}">Review</a>

            @auth
                <div class="dropdown" id="userDropdown">
                    <span style="cursor:pointer;" onclick="toggleDropdown()"> {{ auth()->user()->name }} ▼ </span>
                    <div class="dropdown-content" id="dropdownMenu">
                        <a href="{{ route('profile.index') }}">Profile</a>
                        <form action="{{ route('logout') }}" method="POST" style="margin: 0;">
                            @csrf
                            <button type="submit" class="dropdown-link">Logout</button>
                        </form>
                    </div>
                </div>
            @else
                <a href="{{ route('login') }}">Login</a>
            @endauth
        </div>
    </nav>
</header>
