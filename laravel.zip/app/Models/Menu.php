<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Menu extends Model
{
    //
    use HasFactory;
    
    protected $fillable = [
        'name',
        'price',
        'descrition',
        'image',
        'subcategory_id'
    ];

    public function subcategory(){
        return $this->belongsTo(Subcategory::class);
    }

    public function reviews() {
    return $this->hasMany(Review::class);
    }
}
