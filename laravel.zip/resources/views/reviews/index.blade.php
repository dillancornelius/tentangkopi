@extends('layouts.app')

@section('title')
    Ulasan
@endsection

@section('content')
    <h2 style="text-align: center">Halaman Ulasan</h2>

    @if(session('success'))
        <div style="text-align: center; margin-bottom: 1rem">{{ session('success') }}</div>
    @endif

    @if(session('error'))
        <div style="text-align: center">{{ session('error') }}</div>
    @endif

    @auth
        <form action="{{ route('reviews.store') }}" method="POST" class="order-history">
            @csrf
            <textarea name="comment" rows="3" placeholder="Tulis ulasan..." required></textarea>
            <br>
            <button type="submit">Kirim Ulasan</button>
        </form>
    @else
        <p><em>Silakan login untuk menulis ulasan.</em></p>
    @endauth

    <hr>

    @foreach($reviews as $review)
        <div class="review">
            <strong>{{ $review->user->name }}</strong>
            <p>{{ $review->comment }}</p>

            @auth
                @if($review->user_id === auth()->id())
                    <form action="{{ route('reviews.destroy', $review) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Hapus</button>
                    </form>

                    <a href="{{ route('reviews.edit', $review) }}"><button>Edit</button></a>
                @endif
            @endauth
        </div>
        <hr>
    @endforeach
@endsection
