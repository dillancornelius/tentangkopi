<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel - CoffeeShop</title>
    <link rel="stylesheet" href="{{ asset('css/admin.css') }}">
</head>
<body class="layout">
    <!-- Sidebar -->
    <aside>
        <div class="brand">CoffeeShop Admin</div>
        <nav>
            <a href="{{ route('admin.dashboard') }}">Dashboard</a>
            <a href="{{ route('admin.users.index') }}">Users</a>
            <a href="{{ route('admin.menus.index') }}">Menu</a>
            <a href="{{ route('admin.status.index') }}">Order Status</a>
            <form action="{{ route('logout') }}" method="POST" class="nav-form">
                @csrf
                <button type="submit" class="nav-button">Logout</button>
            </form>
        </nav>
    </aside>

    <!-- Main content -->
    <main>
        @yield('content')
    </main>
</body>
</html>
