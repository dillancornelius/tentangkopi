@extends('layouts.app')

@section('title')
    Pembayaran
@endsection

@section('content')
<div class="order-history">
    <h1>Checkout</h1>

    <div class="checkout-container">
        <form method="POST" action="{{ route('checkout.process') }}" class="checkout-form">
            @csrf
            <div class="form-group">
                <label for="name">Nama</label>
                <input type="text" name="name" id="name" value="{{ old('name') }}" required>
                @error('name') <small class="error">{{ $message }}</small> @enderror
            </div>

            <div class="form-group">
                <label for="phone">No. Telepon</label>
                <input type="text" name="phone" id="phone" value="{{ old('phone') }}" required>
                @error('phone') <small class="error">{{ $message }}</small> @enderror
            </div>

            <div class="form-group">
                <label for="address">Alamat Pengiriman</label>
                <textarea name="address" id="address" required>{{ old('address') }}</textarea>
                @error('address') <small class="error">{{ $message }}</small> @enderror
            </div>

            <div class="form-group">
                <label for="note">Catatan (Opsional)</label>
                <textarea name="note" id="note">{{ old('note') }}</textarea>
            </div>

            <button type="submit" class="btn btn-primary">Proses Pesanan</button>
        </form>

        <div class="payment-method">
            <h3>Metode Pembayaran</h3>
            <p><strong>Cash Only</strong> - Pembayaran dilakukan saat pesanan diterima.</p>
        </div>

        <div class="checkout-summary">
            <h2>Ringkasan Pesanan</h2>
            <button id="clear-cart-btn">Kosongkan Keranjang</button>
            <ul class="cart-list">
                @foreach($cart as $id => $item)
                    <div class="cart-item" data-id="{{ $id }}">
                        <span>{{ $item['name'] }}</span>
                        <span>Rp {{ number_format($item['price'], 0, ',', '.') }}</span>
                        <div class="quantity-control">
                            <button class="decrease-btn">-</button>
                            <span class="qty">{{ $item['quantity'] }}</span>
                            <button class="increase-btn">+</button>
                        </div>
                    </div>
                @endforeach
            </ul>

            <hr>
            <div class="summary-line">
                <span>Subtotal</span>
                <span>Rp {{ number_format($subtotal, 0, ',', '.') }}</span>
            </div>
            <div class="summary-line">
                <span>Pajak (10%)</span>
                <span>Rp {{ number_format($taxAmount, 0, ',', '.') }}</span>
            </div>
            <div class="summary-line">
                <span>Ongkir</span>
                <span>Rp {{ number_format($deliveryFee, 0, ',', '.') }}</span>
            </div>
            <hr>
            <div class="summary-total">
                <strong>Total</strong>
                <strong>Rp {{ number_format($total, 0, ',', '.') }}</strong>
            </div>
        </div>
    </div>
</div>
@endsection
