@extends('layouts.admin')

@section('content')
    <h1>Create User</h1>
    <form method="POST" action="{{ route('admin.users.store') }}">
        @include('admin.users._form')
    </form>
@endsection
