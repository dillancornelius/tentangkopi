@extends('layouts.app')

@section('title', 'Tentang Kami')

@section('content')
    <section class="about-section light">
        <div class="container">
            <div class="row normal">
                <div class="image">
                    <img src="{{ asset('assets/aboutus2.jpg') }}" alt="Tentang Kami 1">
                </div>
                <div class="text">
                    <h2>Tentang Kami</h2>
                    <p>Tentang kopi mengadopsi konsep fresh to cup yang menyajikan pilihan 
                    kopi lokal dengan bahan baku terbaik dan penyajian yang kekinian demi 
                    menciptakan produk kopi terbaik di Indonesia. 
                    Dapat membantu para calon coffepreneur dalam mengembangkan bisninya 
                    agar bisa berkembang dengan memiliki manajemen resiko terbaik 
                    sehingga dapat bersaing dengan brand lain adalah komitmen.
                    </p>
                    <p class="text-p1">Tentang Kopi.</p>
                    <p>Berawal dari sebuah komunitas usaha dan pengalaman 
                    lebih dari 5 tahun, kami berkeinginan untuk terus membantu mencetak 
                    pengusaha baru di bidang kuliner agar turut serta membantu 
                    meningkatkan perekonomian bangsa Indonesia, dan terus menyediakan 
                    lapangan kerja baru bagi masyarakat.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section dark">
        <div class="container">
            <div class="row reverse">
                <div class="image">
                    <img src="{{ asset('assets/aboutus1.jpg') }}" alt="Tentang Kami 2">
                </div>
                <div class="text">
                    <h2>Keunggulan Kami</h2>
                    <p class="text-p1">No Royalty Fee</p>
                    <p>Kami mendukung perkembangan mitra dengan tidak mengutip 
                    apapun dari mitra setelah opening. Tidak memonopoli bahan baku, 
                    kendala yang sering terjadi di franchise/waralaba, dengan tingginya 
                    harga bahan baku yang dijual pihak franchisor sehingga menyebabkan 
                    tingginya HPP dan mempengaruhi profit dan harga jual.
                    </p>
                    <p class="text-p1">Bebas Menambah Menu</p>
                    <p>Ketika sebuah menu habis trendnya atau tidak laku di lokasi tertentu, 
                    bangkrut jadi pilihan pasti. Dengan melihat kendala ini, kami melihat salah satu 
                    manajemen resiko terbaik adalah dengan memberikan kesempatan kepada 
                    mitra kami untuk inovatif dalam penambahan menu.
                    </p>
                    <p class="text-p1">Pelatihan Bisnis</p>
                    <p>Bukan sekedar membeli merek, Tentang Kopi juga mengajarkan 
                    setiap mitra cata menjadi coffepreneur bagaimana menjalankan bisnis.
                    </p>
                </div>
            </div>
        </div>
    </section>
@endsection
