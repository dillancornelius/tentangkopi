<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Order;

class OrderStatusController extends Controller
{
    //Menampilkan laman status dan mengambil data pesanan
    public function index(){
        $orders = Order::latest()->get();
        return view('admin.status.index', compact('orders'));
    }

    //Mengupdate status pesanan
    public function update(Request $request, Order $order)
    {
        $request->validate([
            'status' => 'required|in:pending,confirmed,cancelled,completed',
        ]);

        $order->update(['status' => $request->status]);

        return redirect()->route('admin.status.index')->with('success', 'Order status updated successfully.');
    }
}
